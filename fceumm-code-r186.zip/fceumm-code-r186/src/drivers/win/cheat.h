void ConfigCheats(HWND hParent);
void ConfigAddCheat(HWND wnd);
