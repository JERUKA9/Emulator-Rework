void KeyboardUpdateState(void);
void KeyboardClose(void);
int KeyboardInitialize(void);
void KeyboardUpdate(void);
char *GetKeyboard(void);

