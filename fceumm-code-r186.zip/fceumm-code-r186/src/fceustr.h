typedef struct {
	uint8 *data;
	uint32 len;	/* Not including extra NULL character. */
} fceustr;
