uint32 CalcCRC32(uint32 crc, uint8 *buf, uint32 len);
