void UpdateBasicBot();
void CreateBasicBot();
extern char *BasicBotDir;
