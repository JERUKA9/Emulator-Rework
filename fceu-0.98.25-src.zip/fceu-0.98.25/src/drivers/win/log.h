void MakeLogWindow(void);
void AddLogText(char *text,int newline);
