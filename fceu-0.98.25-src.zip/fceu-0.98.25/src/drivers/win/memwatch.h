void UpdateMemWatch();
void CreateMemWatch();
extern char * MemWatchDir;
