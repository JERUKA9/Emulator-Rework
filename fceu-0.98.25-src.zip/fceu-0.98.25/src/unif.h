/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

void ANROM_Init(CartInfo *info);

void HKROM_Init(CartInfo *info);

void ETROM_Init(CartInfo *info);
void EKROM_Init(CartInfo *info);
void ELROM_Init(CartInfo *info);
void EWROM_Init(CartInfo *info);

void SAROM_Init(CartInfo *info);
void SBROM_Init(CartInfo *info);
void SCROM_Init(CartInfo *info);
void SEROM_Init(CartInfo *info);
void SGROM_Init(CartInfo *info);
void SKROM_Init(CartInfo *info);
void SLROM_Init(CartInfo *info);
void SL1ROM_Init(CartInfo *info);
void SNROM_Init(CartInfo *info);
void SOROM_Init(CartInfo *info);

void NROM_Init(CartInfo *info);
void MHROM_Init(CartInfo *info);
void UNROM_Init(CartInfo *info);
void SUNSOFT_UNROM_Init(CartInfo *info); // "Shanghi" original version mapper
void MALEE_Init(CartInfo *info);
void CNROM_Init(CartInfo *info);
void CPROM_Init(CartInfo *info);
void GNROM_Init(CartInfo *info);

void TEROM_Init(CartInfo *info);
void TFROM_Init(CartInfo *info);
void TGROM_Init(CartInfo *info);
void TKROM_Init(CartInfo *info);
void TSROM_Init(CartInfo *info);
void TLROM_Init(CartInfo *info);
void TLSROM_Init(CartInfo *info);
void TKSROM_Init(CartInfo *info);
void TQROM_Init(CartInfo *info);
void TQROM_Init(CartInfo *info);

void DEIROM_Init(CartInfo *info);

void TCA01_Init(CartInfo *info);
void TCU01_Init(CartInfo *info);
void S8259A_Init(CartInfo *info);
void S8259B_Init(CartInfo *info);
void S8259C_Init(CartInfo *info);
void S8259D_Init(CartInfo *info);
void S74LS374N_Init(CartInfo *info);
void S74LS374NA_Init(CartInfo *info);
void SA0161M_Init(CartInfo *info);

void SA72007_Init(CartInfo *info);
void SA72008_Init(CartInfo *info);
void SA0036_Init(CartInfo *info);
void SA0037_Init(CartInfo *info);

void Supervision16_Init(CartInfo *info);
void Super24_Init(CartInfo *info);
void Novel_Init(CartInfo *info);

void BMC42in1r_Init(CartInfo *info);
void BMC64in1nr_Init(CartInfo *info);
void BMC70in1_Init(CartInfo *info);
void BMC70in1B_Init(CartInfo *info);
void BMC13in1JY110_Init(CartInfo *info);
void BMCT262_Init(CartInfo *info);
void BMCFK23C_Init(CartInfo *info);

void DreamTech01_Init(CartInfo *info);
void Mapper190_Init(CartInfo *info);
void UNLCC21_Init(CartInfo *info);
void UNLSL1632_Init(CartInfo *info);
void UNLKOF97_Init(CartInfo *info);
void UNLSonic_Init(CartInfo *info);
void UNLSHeroes_Init(CartInfo *info);
void UNLH2288_Init(CartInfo *info);
void UNL8237_Init(CartInfo *info);
void UNL8157_Init(CartInfo *info);

extern uint8 *UNIFchrrama;  // Meh.  So I can stop CHR RAM
         // bank switcherooing with certain boards...
